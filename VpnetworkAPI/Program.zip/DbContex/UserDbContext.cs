﻿using Microsoft.EntityFrameworkCore;
using VpnetworkAPI.Models;

namespace VpnetworkAPI.DbContex
{
    public class UserDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Analysis> Analyses { get; set; }
        public DbSet<GlobalProgramData> GlobalData{ get; set; }
        public DbSet<ProgramData> ProgramData { get; set; }
        public DbSet<LocalProgramData> LocalProgramData { get; set; }
        public DbSet<ThresholdSettings> ThresholdSettings { get; set; }

        public UserDbContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // User - ProgramData relationship
            modelBuilder.Entity<User>()
    .HasMany(u => u.ProgramData)
    .WithOne(pd => pd.User);

            // Unique constraint for ProgramData
            modelBuilder.Entity<ProgramData>()
    .HasIndex(pd => new { pd.UserId, pd.ProgramName })
    .IsUnique();

            // User - LocalProgramData relationship
            modelBuilder.Entity<User>()
         .HasMany(u => u.LocalProgramData)
         .WithOne(ld => ld.User);

            // User - ThresholdSettings relationship
            modelBuilder.Entity<User>()
                .HasMany(u => u.ThresholdSettings)
                .WithOne(ts => ts.User);

            modelBuilder.Entity<User>()
               .HasMany(u => u.Analyses)
               .WithOne(a => a.User);

            // Setting GUID as the primary key for Analysis
            modelBuilder.Entity<Analysis>()
                .HasKey(a => a.AnalysisId);

        }
    }
}
